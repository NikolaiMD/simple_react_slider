import React from 'react';
import './App.css';
import './components/Basis.js';
import Carousel from './components/Basis.js';

function App() {
  return (
    <div className="main">
      <Carousel/>
    </div>
  );
}

export default App;
