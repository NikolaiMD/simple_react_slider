import React, {Component} from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faChevronLeft } from "@fortawesome/free-solid-svg-icons";
import { faChevronRight } from "@fortawesome/free-solid-svg-icons";
import './styles.scss';

class Carousel extends Component{
  constructor(){
    super();
    this.state = {
      currentPictureIndex: 0,
      images:[
        'https://picsum.photos/id/237/800/500',
        'https://picsum.photos/id/227/800/500',
        'https://picsum.photos/id/137/800/500',
        'https://picsum.photos/id/337/800/500',
        'https://picsum.photos/id/543/800/500',
        'https://picsum.photos/id/27/800/500'
      ],
    };
    this.NextPicture=this.NextPicture.bind(this);
    this.PreviousPicture=this.PreviousPicture.bind(this);
  }
  // buttons logic
  PreviousPicture(){
    // last image in array
    var lastIndex = this.state.images.length-1;
    // resetting index when needed
    var resetIndex = this.state.currentPictureIndex === 0;
    // index+1
    var index = resetIndex ? lastIndex : this.state.currentPictureIndex - 1;
    // rendering picture with right lastIndex
    this.setState({currentPictureIndex: index})
  }

  NextPicture(){
    // last image in array
    var lastIndex = this.state.images.length-1;
    // resetting index when needed
    var resetIndex = this.state.currentPictureIndex === lastIndex;
    // index+1
    var index = resetIndex ? 0 : this.state.currentPictureIndex + 1;
    // rendering picture with right lastIndex
    this.setState({currentPictureIndex: index})
  }
  render(){
    var index = this.state.currentPictureIndex;
    // preview with first five pictures
    var preview = this.state.images.slice(index, index+1);
    return(
      <div className="carousel-box">
        <div>
          {preview.map((image, index) => <img key={index} src={image} alt=""/>)}
        </div>
        <div className="button-box">
          <button className="prev" onClick={this.PreviousPicture}><FontAwesomeIcon icon={faChevronLeft}/></button>
          <button className="next" onClick={this.NextPicture}><FontAwesomeIcon icon={faChevronRight}/></button>
        </div>
      </div>
    )
  }
}

export default Carousel;
